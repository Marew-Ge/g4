import ourConnection from "../Server.js";
import ourTable from '../Schema/schema.js'

let createTable = (req, res) => {
    ourConnection.query(ourTable, (err) => {
        if (err) {
            console.log(err)
        } 
      console.log("done")
    })
    res.send("tableCreated");
    res.end()
}

export default createTable;