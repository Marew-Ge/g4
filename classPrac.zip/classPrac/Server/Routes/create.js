import express from 'express';
import table from '../Controller/createC.js'

const createRoute = express.Router();

createRoute.get('/create', table);

export default createRoute;