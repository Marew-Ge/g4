import express from 'express';
import mysql from 'mysql';
import dotenv from 'dotenv';

// config dotenv
dotenv.config()
// initialize express to access everything
let app = express();
// main routing 
import createRoute from './Routes/create.js'
app.use('/pharmacy', createRoute)
// create connection information
let ourConnection = mysql.createConnection({
    // for mack socketPath :
    host: "localhost",
    database: "pharmacy",
    user: "group4",
    password: "group4"
});



//connectiong with dtabase
ourConnection.connect((err) => {
    if (err) {
        console.log(`err ${ err }`)
    } else {
        console.log("sucess")
    }
});


// listener funcion 
app.listen(process.env.PORT, 511, () => {
    console.log(`server is listening to port ${process.env.PORT}}`)
})

// eport 
export default ourConnection;







