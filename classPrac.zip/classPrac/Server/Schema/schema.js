let pharmacy = `CREATE TABLE if not exists pharmacy(
    medhanit int auto_increment,
    name varchar(255) not null,
    manuf_date  varchar(255) not null,
    exp_date   varchar(255),
    lot_num  varchar(255),
    PRIMARY KEY(medhanit)
)`;
export default pharmacy;